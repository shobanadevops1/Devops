# Introduction 
This is a self hosted windows agent with following pre-installed capabilites

Capability Name | Version |
--- | --- |
git-lfs | v2.13.1 |
svn | 1.14.0 |
python | 3.9.1 |


# How to update the capabilites?
To update the self hosted agent with new versions of capabilites, change the versions in the Dockerfile of the agent.
1.	To update python, please replace the old version with new version by setting the PYTHON_VERSION, PYTHON_RELEASE and PYTHON_PIP_VERSION.
2.	To update svn, please replace the URL of old version with the URL of newest version.
3.	To update git-lfs, please replace the URL of old version with the URL of newest version.